<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app = new \Slim\App;

// Get All cars
$app->get('/api/cars', function(Request $request, Response $response){
    $sql = "SELECT * FROM car";

    try{
        //Get DB Object
        $db = new db();
        //Connect
        $db = $db->connect();

        $stmt = $db->query($sql);
        $car = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db = null;
        echo json_encode($car);

    } catch(PDOException $e){
        echo '{"error": {"text": '.$e->getMessage().'}';

    }

});
    // Get Single car
$app->get('/api/car/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    
    $sql = "SELECT * FROM car WHERE id = $id";

    try{
        //Get DB Object
        $db = new db();
        //Connect
        $db = $db->connect();

        $stmt = $db->query($sql);
        $car = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db = null;
        echo json_encode($car);

    } catch(PDOException $e){
        echo '{"error": {"text": '.$e->getMessage().'}';

    }
});
   // Add car
   $app->post('/api/car/add', function(Request $request, Response $response){
    $brand = $request->getParam('brand');
    $model = $request->getParam('model');
    $year_make = $request->getParam('year_make');
    

    $sql = "INSERT INTO car (brand,model,year_make) VALUES (:brand,:model,:year_make)";

    try{
        //Get DB Object
        $db = new db();
        //Connect
        $db = $db->connect();

        $stmt = $db->prepare($sql);

        $stmt->bindParam(':brand',$brand);
        $stmt->bindParam(':model',$model);
        $stmt->bindParam(':year_make',$year_make);

        $stmt->execute();

        echo '{"notice": {"text": "car was Added"}';

    } catch(PDOException $e){
        echo '{"error": {"text": '.$e->getMessage().'}';

    }
});
   // Update car
   $app->put('/api/car/update/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $brand = $request->getParam('brand');
    $model = $request->getParam('model');
    $year_make = $request->getParam('year_make');
    

    $sql = "UPDATE car SET
                brand = :brand,
                model = :model,
                year_make = :year_make
            WHERE id = $id";

    try{
        //Get DB Object
        $db = new db();
        //Connect
        $db = $db->connect();

        $stmt = $db->prepare($sql);

        $stmt->bindParam(':brand',$brand);
        $stmt->bindParam(':model',$model);
        $stmt->bindParam(':year_make',$year_make);

        $stmt->execute();

        echo '{"notice": {"text": "car was Updated"}';

    } catch(PDOException $e){
        echo '{"error": {"text": '.$e->getMessage().'}';

    }
});
    // Delete car
    $app->delete('/api/car/delete/{id}', function(Request $request, Response $response){
        $id = $request->getAttribute('id');
        
        $sql = "DELETE FROM car WHERE id = $id";
    
        try{
            //Get DB Object
            $db = new db();
            //Connect
            $db = $db->connect();
    
            $stmt = $db->prepare($sql);
            $stmt->execute();
            $db = null;
    
            echo '{"notice": {"text": "car was Deleted"}';

        } catch(PDOException $e){
            echo '{"error": {"text": '.$e->getMessage().'}';
    
        }
    });
